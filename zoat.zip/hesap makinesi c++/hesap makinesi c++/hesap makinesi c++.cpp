﻿
#include <iostream>
using namespace std;

int main()
{   
    while (true)
    {
        int sayi, sayi2;
        char sonuc_opera;

        cout << "Lütfen hesap yapmak için (1.) sayi girmeniz gerekmektedir.";
        cin >> sayi;

        cout << "Lütfen hesap yapmak için (2.) sayi girmeniz gerekmektedir.";
        cin >> sayi2;

        cout << "Yapacağınız islem türü nedir?  (+, -, *, /): ";
        cin >> sonuc_opera;

        float result;

        switch (sonuc_opera)
        {
        case '+':
            cout << "Sonuç: " << sayi + sayi2 << endl;
            break;
        case '-':
            cout << "Sonuç: " << sayi - sayi2 << endl;
            break;
        case '*':
            cout << "Sonuç: " << sayi * sayi2 << endl;
            break;
        case '/':
            if (sayi2 != 0) {
                cout << "Sonuç: " << sayi / sayi2 << endl;
            }
            else {
                cout << "Hata: Sıfıra bölme hatası!" << endl;
            }
        default:
            cout << "Geçersiz işlem yaptınız lütfen başka bişey diyiniz" << endl;
        }

        return 0;
    }
   
}

